<?php get_header(); ?>

		<section id="content" class="row">

			<div class="columns large-9 large-centered">

				<?php if (have_posts()) : ?>
					<?php while (have_posts()) : the_post(); ?>

					
					<?php the_content() ?>

				   <?php endwhile; endif;?>

					<?php
					// If comments are open or we have at least one comment, load up the comment template.
					//if ( comments_open() || get_comments_number() ) :
					//	comments_template();
					//endif; ?>


			</div> <!-- END CENTERED COLUMN -->

		</section>

<?php get_footer(); ?>
