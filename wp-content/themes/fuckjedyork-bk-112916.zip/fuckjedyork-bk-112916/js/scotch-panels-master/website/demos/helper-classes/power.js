$(function() {

    $('#scotch-panel').scotchPanel({
        direction: 'right',
        duration: 200,
        transition: 'ease',
        clickSelector: '.toggle-panel',
        distanceX: '220px'
    });

});