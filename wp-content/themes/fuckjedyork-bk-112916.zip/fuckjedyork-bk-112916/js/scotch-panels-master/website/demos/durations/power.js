$(function() {

    $('.scotch-panel').scotchPanel({
        containerSelector: 'section',
        clickSelector: '.all-same-time',
        direction: 'left',
        distanceX: '100%',
        enableEscapeKey: true
    });

});