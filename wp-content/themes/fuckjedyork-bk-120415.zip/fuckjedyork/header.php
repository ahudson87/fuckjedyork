<!DOCTYPE html>

<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<link rel="icon" 
      type="image/png" 
      href="http://fuckjedyork.com/wp-content/uploads/2015/12/FJY-favicon.png">
	<title><?php wp_title(); ?></title>
	<script>
	  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

	  ga('create', 'UA-53406626-2', 'auto');
	  ga('send', 'pageview');

	</script>
	<?php wp_head(); ?>
</head>

<body class="home">

	<div id="fb-root"></div>
	<script>(function(d, s, id) {
	  var js, fjs = d.getElementsByTagName(s)[0];
	  if (d.getElementById(id)) return;
	  js = d.createElement(s); js.id = id;
	  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5&appId=204982202896511";
	  fjs.parentNode.insertBefore(js, fjs);
	}(document, 'script', 'facebook-jssdk'));
	</script>

	<div class="off-canvas-wrap" data-offcanvas>
		<div class="inner-wrap">

			<div class="hide-for-large-up">
				<div class="menu-bar">
					<!--a class="left-off-canvas-toggle" href="#" >Menu</a-->
					<button id="mobile-menu" class="left-off-canvas-toggle" href="#mobile-menu">Menu</button>
					<span>Fuck<em>Jed</em>York<em>.com</em></span>
				</div>

				<!-- Off Canvas Menu -->
				<aside class="left-off-canvas-menu">
					<!-- whatever you want goes here -->
					<ul>
						<li><a href="<?php echo get_home_url(); ?>">Home</a></li>
						<li><a href="http://fuckjedyork.com/contributor-sign-up/">Contribute</a></li>
						<li><a href="http://fuckjedyork.com/subscriber-sign-up/">Subscribe</a></li>
					</ul>

					<!-- <footer>
						<a href="mailto:fjedyork@gmail.com" style="font-size: 1rem;">Email the<br> webmaster</a><br><br>
						<a href="http://www.facebook.com/fjedyork" target="_blank" style="font-size: 1rem;">FuckJedYork on Facebook</a><br>
						<span>&#169; Copyright 2015 FuckJedYork.com</span>
					</footer> -->
				</aside>
			</div>

			<!-- main content goes here -->
			<nav class="show-for-large-up">
			<div class="nav-left">
				<ul>
					<li>
						<a href="<?php echo get_home_url(); ?>" class="link-icon-right">Home<span class="icon icon-home"></span></a>
					</li>
				</ul>
			</div>

			<div class="nav-right">
				<ul>
					<li>
						<a href="http://fuckjedyork.com/contributor-sign-up/" class="link-icon-left"><span class="icon icon-contribute"></span>Contribute</a>
					</li>
					<li>
						<a href="http://fuckjedyork.com/subscriber-sign-up/" class="link-icon-left"><span class="icon icon-subscribe"></span>Subscribe</a>
					</li>
				</ul>
			</div>
		</nav>