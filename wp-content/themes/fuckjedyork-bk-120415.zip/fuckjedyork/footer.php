			<!-- <footer class="show-for-large-up">
				<div class="nav-left">
					<a href="http://www.facebook.com/fjedyork" target="_blank">FuckJedYork on Facebook</a><br>
					<span>&#169; Copyright <?php echo date('Y'); ?> FuckJedYork.com</span>
				</div>
				<div class="nav-right">
					<a href="mailto:fjedyork@gmail.com">Email the webmaster</a>
				</div>
			</footer> -->

			<!-- close the off-canvas menu -->
			<a class="exit-off-canvas"></a>

		</div>
	</div>


	<div id="social-footer">
		<div class="social-expand-holder">
			<span class="social-expand-icon"></span>
		</div>
		<div id="social-expanded">
			<div class="social-close-holder">
				<span class="social-close-x"></span>
			</div>
			<div class="fb-like" data-href="http://www.facebook.com/fjedyork" data-layout="button_count" data-action="like" data-show-faces="true" data-share="true"></div>
			<a href="https://twitter.com/fork_york" class="twitter-follow-button" data-show-count="false">Follow @fork_york</a>
			<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document, 'script', 'twitter-wjs');
			</script>
			<a href="mailto:fjedyork@gmail.com">Contact us</a>
			<span id="copyright">&#169; Copyright <?php echo date('Y'); ?> FuckJedYork.com</span>
		</div>
	</div>


	<div id="modal-overlay" class="hide-the-modal"> <!-- START MODAL OVERLAY -->

		<div id="welcome-modal" class="modal-window"> <!-- START WELCOME MODAL -->
			<button class="close-modal">Close</button>
			<h1>Welcome to FuckJedYork.com</h1>
			<p>This site is all about holding Jed York accountable for the disaster that is the 2015-16 49ers season (and likely years to come). We, as fans, may have little-to-no authority to influence change, but let this blog serve as a unified front for fans of the team, the sport, and the spirit of competition, to have their message heard.</p>
			<p><strong>Fuck you, Jed York. This is your fault.</strong></p>
			<p>Subscribe and be notified whenever new articles or commentary are posted to the site. Sign-up to be a contributor and have your message broadcast to the world. We can't do this alone.</p>
			<a href="http://fuckjedyork.com/contributor-sign-up/">Contribute Now!</a>
		</div> <!-- END WELCOME MODAL -->

	</div> <!-- END MODAL OVERLAY -->

	<?php wp_footer(); ?>

</body>

</html>