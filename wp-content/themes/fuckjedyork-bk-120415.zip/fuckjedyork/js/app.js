jQuery(document).ready(function($) {

	$(document).foundation();

	// $( "#welcome-modal" ).show();
	// $( "#modal-overlay" ).toggleClass("hide-the-modal");

	$('#panel-example').scotchPanel({
	    containerSelector: 'body', // As a jQuery Selector
	    direction: 'left', // Make it toggle in from the left
	    duration: 300, // Speed in ms how fast you want it to be
	    transition: 'ease', // CSS3 transition type: linear, ease, ease-in, ease-out, ease-in-out, cubic-bezier(P1x,P1y,P2x,P2y)
	    clickSelector: '.toggle-panel', // Enables toggling when clicking elements of this class
	    distanceX: '70%', // Size fo the toggle
	    enableEscapeKey: true // Clicking Esc will close the panel
	});

	var $socialFooterCloseButton = $("#social-footer .social-close-x");
	var $socialButtonsList = $("#social-expanded");
	var $socialFooterExpandHolder = $("#social-footer .social-expand-holder");
	var $socialFooterExpandButton = $("#social-footer .social-expand-icon");
	var $socialButtonsVisible = true;
	$socialFooterCloseButton.click(function() {
		if ($socialButtonsVisible) {
			$socialButtonsList.hide("fast");
			$socialFooterExpandHolder.show("fast");
			$socialButtonsVisible = false;
		}
	});
	$socialFooterExpandButton.click(function() {
		if (!$socialButtonsVisible) {
			$socialButtonsList.show("fast");
			$socialFooterExpandHolder.hide("fast");
			$socialButtonsVisible = true;
		}
	});

	if (document.documentElement.clientWidth < 810) {
		setTimeout(function(){
			if ($socialButtonsVisible) {
				$socialButtonsList.hide("slow");
				$socialFooterExpandHolder.show("slow");
				$socialButtonsVisible = false;
			}
		}, 3500);
	}


	$( "#contribute-modal" ).hide();
	$( "#subscribe-modal" ).hide();

	$( "#contribute-trigger" ).click(function() {
		$( "#contribute-modal" ).show();
	 	$('#modal-overlay').toggleClass("hide-the-modal");
	});

	$( "#subscribe-trigger" ).click(function() {
		$( "#subscribe-modal" ).show();
	 	$('#modal-overlay').toggleClass("hide-the-modal");
	});

	$( ".close-modal" ).click(function() {
	 	$( "#modal-overlay" ).toggleClass("hide-the-modal");
	 	$( "#contribute-modal" ).hide();
		$( "#subscribe-modal" ).hide();
		$( "#welcome-modal" ).hide();
	});

 });