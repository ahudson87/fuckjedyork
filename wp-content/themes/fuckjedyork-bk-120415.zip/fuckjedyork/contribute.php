<?php get_header(); ?>

		<section id="content" class="row">

			<div class="columns large-9 large-centered">

				<h1>Contribute to the blog</h1>

			</div> <!-- END CENTERED COLUMN -->

		</section>

<?php get_footer(); ?>
